"""Initialize the api"""
from .api import pull
from .api import push
from .api import clone
from .base import Lich
